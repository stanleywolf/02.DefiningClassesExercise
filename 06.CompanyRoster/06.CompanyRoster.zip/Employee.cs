﻿using System;
using System.Collections.Generic;
using System.Text;


public class Employee
{
    private string name;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }
    private decimal salary;

    public decimal Salary
    {
        get { return salary; }
        set { salary = value; }
    }
    private string position;

    public string Position
    {
        get { return position; }
        set { position = value; }
    }
    private  Department department;

    public Department Department
    {
        get { return this.department; }
        set { this.department = value; }
    }
   
    private string email;

    public string Email
    {
        get { return email; }
        set { email = value; }
    }
    private int age;

    public int Age
    {
        get { return age; }
        set { age = value; }
    }   

    public Employee(string name,  decimal salary, string position, string email = "n/a", int age = -1)
    {
        this.Name = name;
        this.Position = position;
        this.Salary = salary;
        this.Email = email;
        this.Age = age;
    }

}

