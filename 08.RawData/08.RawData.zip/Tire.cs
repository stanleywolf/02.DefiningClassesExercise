﻿public class Tire
{
    private double pressure;

    public double Pressure
    {
        get { return pressure; }
        set { pressure = value; }
    }


    public Tire(double pressure)
    {
        this.pressure = pressure;
        
    }

    
}